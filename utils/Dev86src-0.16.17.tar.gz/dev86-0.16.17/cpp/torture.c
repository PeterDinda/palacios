/\
* \    This _evil_ little file is compilable Ansi C.
* /    There are NO extensions ... Waddya think ?				
\/

// ***/ func() { printf("Hello /* world */ %d ???/?=\n" ??/
, 1?
'\\
007':
'??/"'/*"*/
      );}

      
main() 
{
   func();

}
