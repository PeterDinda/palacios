/* setpassent.c - vacuous setpassent for BSD - rick sladkey */

void setpassent(i)
int i;
{
}
