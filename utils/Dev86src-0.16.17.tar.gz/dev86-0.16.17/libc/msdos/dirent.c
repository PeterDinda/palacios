
opendir

closedir

readdir 

rewinddir
