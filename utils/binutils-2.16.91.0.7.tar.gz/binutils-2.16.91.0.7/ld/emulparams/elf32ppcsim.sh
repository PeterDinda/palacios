. ${srcdir}/emulparams/elf32ppc.sh
TEXT_START_ADDR=0x10000000
