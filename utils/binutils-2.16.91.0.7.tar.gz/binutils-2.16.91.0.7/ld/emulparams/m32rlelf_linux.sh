. ${srcdir}/emulparams/m32relf_linux.sh
OUTPUT_FORMAT="elf32-m32rle-linux"
