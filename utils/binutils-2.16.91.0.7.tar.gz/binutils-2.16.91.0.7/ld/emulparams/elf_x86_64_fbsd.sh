. ${srcdir}/emulparams/elf_x86_64.sh
. ${srcdir}/emulparams/elf_fbsd.sh
