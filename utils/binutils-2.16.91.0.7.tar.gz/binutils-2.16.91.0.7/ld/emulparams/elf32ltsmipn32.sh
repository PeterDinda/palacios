. ${srcdir}/emulparams/elf32btsmipn32.sh
OUTPUT_FORMAT="elf32-ntradlittlemips"
BIG_OUTPUT_FORMAT="elf32-ntradbigmips"
LITTLE_OUTPUT_FORMAT="elf32-ntradlittlemips"
