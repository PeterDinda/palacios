. ${srcdir}/emulparams/elf64ppc.sh
OUTPUT_FORMAT="elf64-powerpcle"
NOP=0x00000060
