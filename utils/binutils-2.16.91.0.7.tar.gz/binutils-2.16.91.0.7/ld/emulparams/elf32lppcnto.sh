. ${srcdir}/emulparams/elf32ppc.sh
OUTPUT_FORMAT="elf32-powerpcle"
MAXPAGESIZE=0x1000
TEXT_START_ADDR=0x48040000

