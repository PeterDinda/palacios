. ${srcdir}/emulparams/elf32btsmip.sh
OUTPUT_FORMAT="elf32-tradlittlemips"
