# If you change this file, please also look at files which source this one:
# elf32lppcsim.sh

. ${srcdir}/emulparams/elf32ppc.sh
OUTPUT_FORMAT="elf32-powerpcle"
