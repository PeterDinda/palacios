. ${srcdir}/emulparams/elf32ppccommon.sh
OUTPUT_FORMAT="elf32-powerpc-vxworks"
. ${srcdir}/emulparams/vxworks.sh
