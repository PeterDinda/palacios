. ${srcdir}/emulparams/elf64_sparc.sh
. ${srcdir}/emulparams/elf_fbsd.sh
