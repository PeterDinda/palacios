EMBEDDED=yes
. ${srcdir}/emulparams/elf32lmip.sh
