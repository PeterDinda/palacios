extern void bar ();
extern void foo ();

int
main ()
{
  bar ();
  foo ();
  return 0;
}
