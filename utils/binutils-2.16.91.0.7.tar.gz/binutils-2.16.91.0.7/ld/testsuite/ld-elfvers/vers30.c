void global (void) {}
void local (void) {}
void foo (void) {}
void bar (void) {}
void info (void) {}
void baz (void) __asm ("extern");
void baz (void) {}
