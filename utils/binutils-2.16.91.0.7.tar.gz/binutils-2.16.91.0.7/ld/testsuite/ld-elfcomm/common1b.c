static char dummy1 = 'X';
char foo1 [] = "Aligned at odd byte.";
char foo2 [4];
