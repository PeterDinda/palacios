#! /bin/sh

./parent_process
./parent_process "param1 param2" param3
